<?php
namespace Gw\Constants;

class MessageConst {
  // 信息状态：草稿
  const STATUS_DRAFT = 1;

  // 信息状态：已发送
  const STATUS_SENT = 2;
}
