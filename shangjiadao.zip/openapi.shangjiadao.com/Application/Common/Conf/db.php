<?php

/**
 * 数据库配置文件
 */
return array (
  'DB_TYPE'     => 'mysql',
  'DB_HOST'     => '172.18.168.232',
  'DB_NAME'     => 'shangjiadao',
  'DB_USER'     => 'ops_api_test',
  'DB_PWD'      => '123456',
  'DB_PORT'     => '3306',
  'DB_PREFIX'   => 'sjd_',
);

