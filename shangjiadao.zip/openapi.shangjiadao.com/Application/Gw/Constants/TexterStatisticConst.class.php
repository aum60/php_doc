<?php
namespace Gw\Constants;

class TexterStatisticConst
{
  // 统计类型：浏览次数
  const TYPE_VIEW = 1;

  // 统计类型：分享次数
  const TYPE_SHARE = 2;

  // 统计类型：评论次数
  const TYPE_POST = 3;
}
