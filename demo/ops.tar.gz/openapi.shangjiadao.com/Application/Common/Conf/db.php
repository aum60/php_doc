<?php

/**
 * 数据库配置文件
 */
return array (
  'DB_TYPE'     => 'mysql',
  'DB_HOST'     => 'rm-bp178946u0rk4ptjf.mysql.rds.aliyuncs.com',
  'DB_NAME'     => 'shangjiadao',
  'DB_USER'     => 'sjd_production',
  'DB_PWD'      => 'txN9MPFVA6HfgNsN',
  'DB_PORT'     => '3306',
  'DB_PREFIX'   => 'sjd_',
);

