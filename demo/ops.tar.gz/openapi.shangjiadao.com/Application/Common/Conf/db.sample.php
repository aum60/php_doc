<?php

/**
 * 数据库配置文件
 */
return array (
  'DB_TYPE' => 'mysql',
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'shangjiadao',
  'DB_USER' => 'root',
  'DB_PWD' => '',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'sjd_',
);
