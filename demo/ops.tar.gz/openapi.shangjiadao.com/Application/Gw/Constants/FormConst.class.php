<?php
namespace Gw\Constants;

class FormConst
{
  // 活动支付方式：线下
  const PAYMENT_TYPE_OFFLINE = 'offline';

  // 活动支付方式：线上
  const PAYMENT_TYPE_ONLINE = 'online';
}
