<?php
namespace Gw\Constants;

class FlyerConst
{
  // 传单状态：有效
  const STATUS_VALID = 1;

  // 传单状态：无效
  const STATUS_INVALID = 0;
}
