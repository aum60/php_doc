<?php
namespace Gw\Constants;

class TexterPostConst {
  // 状态：有效
  const STATUS_VALID = 1;

  // 状态：无效
  const STATUS_INVALID = 0;
}

