<?php
namespace Gw\Logic;

class CommonLogic
{
  
}